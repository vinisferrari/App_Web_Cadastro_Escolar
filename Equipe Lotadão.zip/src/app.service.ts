import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  // calculaIMC(peso: number, altura: number): number {
  //   return peso / (altura*altura);
  // }
  // msgAviso(): string{
  //   let result = "Para calcular o Índice de Massa Corporal (IMC), complemente a url com o peso (kg) e altura (m).<br>" +
  //   "exemplo: http://localhost:3000/91/1.93";
  //   return result
  // }
}
